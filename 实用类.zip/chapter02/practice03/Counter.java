package cn.book03.chapter02.practice03;

public class Counter {
	public int counter(String inputs, String word) {
		int counter = 0; // ����������ʼ��0
		for (int i = 0; i < inputs.length(); i++) {
			if (inputs.substring(i, i+1).equals(word)) {
				counter++;
			}
		}
		return counter;
	}
}
